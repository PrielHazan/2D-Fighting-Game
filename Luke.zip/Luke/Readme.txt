Luke Skywalker

this is luke skywalker in his cool black suit he was made for the 
starwars lf2 mod currently being worked on by me and others i will 
also make a vader in the near future and an obi-wan,anyway here are 
his attacks:

D>A- Force push

DvA- Force pull

D^A- Force heal self (DvA+A is Force heal others)

D>J- lightsaber throw 

DvJ- Force speed

D^J- Force sheild 

special thanks to Prince legendary for sounds and other things.



Installation:
- Move the sprite-folder and the data-folder into your LF2-directory
- Add these lines to data.txt (to the object-part):

id:   29  type: 0  file: sprite\luke\luke.dat
id:  360  type: 3  file: sprite\luke\luke_ball.dat

- Have fun playing!

______________________________________________________________________

                           www.lf-empire.de

                      Little Fighter EMPIRE v8.0
                           ~ all you need ~