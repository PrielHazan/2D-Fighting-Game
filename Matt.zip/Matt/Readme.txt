Matt

by matt4300


Installation:
- Move all folders into your LF2-directory
- Add these lines to data.txt (to the object-part):

  id:  42 type: 0  file: sprite\matt\matt.dat
  id: 395  type: 3  file: sprite\matt\matt_b3.dat

- Have fun playing!


this is me as an lf2 char.I used every thing i think look good 
on a char, and i used the color green because it looks 
best on me in the real world.I also gave him a ninja sword because 
that is my favorite weapon, and blue energy causeits my favorite 
color, and i drew every thing myself.

enjoy!

______________________________________________________________________

                           www.lf-empire.de

                      Little Fighter EMPIRE v8.0
                           ~ all you need ~