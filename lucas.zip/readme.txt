Pendzik

by Gad


Installation:
- Move all folders into your LF2-directory
- Add these lines to data.txt (to the object-part):

id: 643  type: 3  file: data\Pendzik_ball.dat
id: 11  type: 0  file: data\Pendzik.dat

- Have fun playing!

@@ PENDZIK ATTACKS @@

Kick Out Of Jam - D + v + A  | 70  mp
Electric Ball - D + </> + A  | 150 mp
Electric Dash - D + </> + J  | 200 mp
Electric Tornado - D + ^ + A | 100 mp
Power Dance - D + J + A      | 0   mp


______________________________________________________________________

                           www.lf-empire.de

                      Little Fighter EMPIRE v8.0
                           ~ all you need ~