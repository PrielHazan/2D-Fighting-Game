---Assassin---
creator: 
MoragWan

Credits:
Gad
STM1993

Moves:
D>A - Throwing knives on both sides
D<J - Assassination - Fast stabbing
DVA - Jump fast away from his place he was standing and throws a knife to there

D^J - tries to catch enemy while running.
while running - (J) - will jump and try to catch an enemy in-air and smash him on the ground.
-(A/D) - stop the attack.
While running and catching the enemy, you use the victim as a shield from other enemies, after that you can (A) kick his ass! or (J) Jump and throw him.
While standing and catching the enemy - (D^A) - Throw the enemy up.
- (D>J) - Jump and throw the victim forward.
 -(D>A) - return to run with the victim.
DVJ -  the assassin's knife as a weapon

Installation:
Put this in data.txt file:
id:  8903  type: 0  file: sprite\Assassin\Assassin.dat
id:  8902  type: 3  file: sprite\Assassin\smoke.dat
id: 8901  type: 1  file: sprite\Assassin\weapon.dat   #knife


And copy past the folder "Assassin" into "sprite" folder

Enjoy!