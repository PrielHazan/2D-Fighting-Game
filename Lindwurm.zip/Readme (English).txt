Readme for Lindwurm ~ read before start!


----------------Informations---------------

-Made on Little Fighter 2 v1.9c
-This character is (C) copyright by Scorpion
-Don't rip datas or sprites (also when you give credits)
-Made for http://lf-universe.de.tl


----------------Installation:--------------

Sprites into folder : LF2/sprite/sys/
Datas into folder:    LF2/data/

Write down these to your data.txt (LF2/data/data.txt)

id: 326  type: 0  file: data\lindwurm.dat
id: 678  type: 3  file: data\lindwurm_ball.dat
id: 679  type: 3  file: data\lindwurm_ball2.dat
id: 680  type: 3  file: data\lindwurm_exp.dat


-------------------Moves-------------------

J+J,J...       = Fly
>>A            = Slash 1
J,A/>>J,A      = Slash 2
D>A+AAA        = Fireball + Explode
D>J            = Flamethrow
DvJ+JJ../AAA+A = Fire Wings
D^J            = Healing
DJA            = Division (with 250 HP and full MP)
Grab+D         = Grab Combo 1
Grab+J         = Grab Combo 2

All attacks and moves are archieved here, too:
http://lf-universe.de.tl/Projekte.htm?PHPSESSID=ee2d542945453d1168cb7155c9464f8c


------------------Credits------------------

-Grim for ripping the sprites
-The Sprite Data Base - http://sdb.drshnaps.com
-The Little Fighter Empire - http://www2.lf-empire.de/
-The best german LF2 Clan - http://lf2apocalypse.de.vu


------------------Contact------------------

Did you found any mistakes ? Have any questions ?
Contact me by using this:

ICQ:      390867182
E-Mail:   kahrashin@yahoo.de
MSN:      vfbmathias@msn.de
Homepage: http://lf-universe.de.tl
Hamachi:  (Look at the Homepage!)

You can also write in the LF-Empire Forum in my Thread:
http://www2.lf-empire.de/forum/showthread.php?tid=137&page=1

But don' ask my if you want that i tell you how to make your own character ^^


______________________________________________________________________

                           www.lf-empire.de

                      Little Fighter EMPIRE v8.0
                           ~ all you need ~